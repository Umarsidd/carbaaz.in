import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  ChevronRight,
  ChevronLeft,
  ShieldCheck,
  Sparkles,
  BadgeIndianRupee,
  Headphones,
  Star,
  CarFront,
} from "lucide-react";
import { motion } from "framer-motion";
import {
  useApp,
  Tag,
  Btn,
  ServiceCard,
  CarCard,
  api,
  Submit,
  useAction,
} from "./shared";
const trust = [
  [Sparkles, "Expert detailing", "Precision in every detail"],
  [ShieldCheck, "Pre-owned cars", "Explore our inventory"],
  [BadgeIndianRupee, "Transparent pricing", "Know what you pay"],
  [Headphones, "Personal support", "Here for your journey"],
] as const;
export function Home() {
  const { data } = useApp(),
    [slide, set] = useState(0),
    [start, shift] = useState(0),
    a = useAction();
  const shots = [
    ["hero", "Porsche Panamera"],
    ["bmw", "BMW collection"],
    ["audi", "Audi collection"],
  ];
  return (
    <>
      <section className="hero">
        <div
          className="heroPic"
          key={slide}
          style={{
            backgroundImage:
              "url(" +
              (slide === 0 && data.settings.banner
                ? data.settings.banner
                : "/media/" + shots[slide][0] + ".webp") +
              ")",
          }}
        />
        <div className="heroShade" />
        <div className="shell heroInner">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Tag>THE CARBAAZ EXPERIENCE</Tag>
            <h1>
              Your Car.
              <br />
              Our Passion.
              <br />
              <em>Premium Care.</em>
            </h1>
            <p>
              Experience professional car detailing, premium car care
              <br className="desktop" /> and trusted pre-owned car deals with
              CARBAAZ.
            </p>
            <div className="actions">
              <Btn to="/book-detailing">
                <CalendarDays size={17} /> Book detailing{" "}
                <ArrowUpRight size={16} />
              </Btn>
              <Btn ghost to="/buy-used-cars">
                Browse used cars <ArrowRight size={17} />
              </Btn>
            </div>
          </motion.div>
          <div className="heroBottom">
            <Link to="/services">
              <span>↓</span> EXPLORE SERVICES
            </Link>
            <div className="slider">
              <b>0{slide + 1}</b>
              <i />
              03{" "}
              <button
                aria-label="Previous photograph"
                onClick={() => set((slide + 2) % 3)}
              >
                <ChevronLeft />
              </button>
              <button
                aria-label="Next photograph"
                onClick={() => set((slide + 1) % 3)}
              >
                <ChevronRight />
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="trust">
        <div className="shell trustGrid">
          {trust.map(([I, t, d]) => (
            <div key={t}>
              <I />
              <div>
                <strong>{t}</strong>
                <small>{d}</small>
              </div>
            </div>
          ))}
        </div>
      </section>
      <section className="section shell">
        <Tag>THE DETAILING STUDIO</Tag>
        <div className="heading">
          <div>
            <h2>
              Our signature <em>services.</em>
            </h2>
            <p>Specialist treatments for every surface, inside and out.</p>
          </div>
          <Link className="outline" to="/services">
            View all services <ArrowUpRight size={16} />
          </Link>
        </div>
        <div className="grid">
          {data.services.slice(start, start + 3).map((s: any, i: number) => (
            <ServiceCard key={s.id} s={s} i={i + start} />
          ))}
        </div>
        <div className="pagination">
          <button
            onClick={() => shift(Math.max(0, start - 3))}
            disabled={!start}
          >
            ←
          </button>
          <small>
            {start + 1} – {Math.min(start + 3, data.services.length)} /{" "}
            {data.services.length}
          </small>
          <button
            onClick={() => shift(start + 3)}
            disabled={start + 3 >= data.services.length}
          >
            →
          </button>
        </div>
      </section>
      <section className="band">
        <div className="section shell">
          <Tag>THE MARKETPLACE</Tag>
          <div className="heading">
            <h2>
              Featured <em>vehicles.</em>
            </h2>
            <Link className="outline" to="/buy-used-cars">
              Browse inventory <ArrowUpRight size={16} />
            </Link>
          </div>
          <div className="grid">
            {data.cars
              .filter((c: any) => c.featured)
              .slice(0, 3)
              .map((c: any) => (
                <CarCard c={c} key={c.id} />
              ))}
          </div>
          {!data.cars.length && (
            <p>New vehicles will appear here when listed.</p>
          )}
        </div>
      </section>
      <section className="section shell">
        <Tag>HOW IT WORKS</Tag>
        <h2>Your workshop visit.</h2>
        <div className="grid">
          {["Choose your treatment", "Reserve a time", "Bring your car"].map(
            (n, i) => (
              <div className="panel" key={n}>
                <small>STEP 0{i + 1}</small>
                <h3>{n}</h3>
                <p>
                  {
                    [
                      "Explore services and compare package prices.",
                      "Pick a workshop slot and confirm your details.",
                      "Track confirmation and progress in your account.",
                    ][i]
                  }
                </p>
              </div>
            ),
          )}
        </div>
      </section>
      <section className="section shell duo">
        <div>
          <Tag>OWNER’S GUIDE</Tag>
          <h2>Good to know.</h2>
          {[
            "Can I reschedule my booking?",
            "How do I sell my car?",
            "Where can I track my enquiry?",
          ].map((q, i) => (
            <details key={q}>
              <summary>{q}</summary>
              <p>
                {
                  [
                    "Open My bookings in your customer dashboard and choose an available slot.",
                    "Submit vehicle details in Sell your car. Our team can review the request and record an offer.",
                    "Use your request ID and registered mobile number on Track enquiry.",
                  ][i]
                }
              </p>
            </details>
          ))}
        </div>
        <div className="panel">
          <Tag>CARBAAZ DISPATCH</Tag>
          <h3>Stay in the loop.</h3>
          <p>Receive workshop news and vehicle updates.</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              a.run(() =>
                api("/newsletter", {
                  email: new FormData(e.currentTarget).get("email"),
                }),
              );
            }}
          >
            <input
              name="email"
              type="email"
              placeholder="Your email address"
              required
              aria-label="Newsletter email"
            />
            <Submit busy={a.busy}>Subscribe</Submit>
          </form>
          <p role="status">{a.msg}</p>
        </div>
      </section>
      {data.gallery.length > 0 && (
        <section className="shell section">
          <Tag>WORKSHOP GALLERY</Tag>
          <div className="grid">
            {data.gallery.map((g: any) => (
              <img key={g.id} src={g.value} alt={g.name} />
            ))}
          </div>
        </section>
      )}
      {data.testimonials.length > 0 && (
        <section className="section shell">
          <Tag>OWNER STORIES</Tag>
          {data.testimonials.map((r: any) => (
            <blockquote key={r.id}>
              {r.value} — {r.name}
            </blockquote>
          ))}
        </section>
      )}
      <div className="shell heading section">
        <h2>Let’s talk cars.</h2>
        <Btn to="/contact">
          Contact CARBAAZ <ArrowRight size={16} />
        </Btn>
      </div>
    </>
  );
}
